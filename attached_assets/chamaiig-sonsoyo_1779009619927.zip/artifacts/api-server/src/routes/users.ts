import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, classroomsTable, insertUserSchema, insertClassroomSchema } from "@workspace/db";
import { eq } from "drizzle-orm";
import { z } from "zod";

const router = Router();

router.get("/users", async (req, res) => {
  try {
    const { role } = req.query;
    let users = await db.select().from(usersTable);
    if (role) users = users.filter((u) => u.role === role);
    res.json(users);
  } catch (err) {
    req.log.error({ err }, "Failed to get users");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/users", async (req, res) => {
  try {
    const parsed = insertUserSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid input" });
    const [user] = await db.insert(usersTable).values(parsed.data).returning();
    res.status(201).json(user);
  } catch (err) {
    req.log.error({ err }, "Failed to create user");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/users/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
    const updateSchema = z.object({
      name: z.string().optional(),
      email: z.string().optional(),
      role: z.string().optional(),
      isActive: z.boolean().optional(),
      classroomId: z.number().optional(),
    });
    const parsed = updateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid input" });
    const [updated] = await db.update(usersTable).set(parsed.data).where(eq(usersTable.id, id)).returning();
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(updated);
  } catch (err) {
    req.log.error({ err }, "Failed to update user");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/classrooms", async (req, res) => {
  try {
    const classrooms = await db.select().from(classroomsTable);
    res.json(classrooms);
  } catch (err) {
    req.log.error({ err }, "Failed to get classrooms");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
